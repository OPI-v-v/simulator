//Simulator 2.0
//Avtor: Primo� Volker
//Verzija: 2.0 (14.1.2021) - koncna
#include <iostream>		// vkljucitev potrebnih knjiznic
#include <string>
#include <fstream>
#include <windows.h>	//uporaba Sleep()
#include <ctime>		//uporaba v mainu, za nakljucna st
using namespace std;

char vnos;
string ime_dat;
string st_sim_c;
string vsebina_dat;		//potrebne spremenljivke za vnos iz tipkovnice, za shranitev imena datoteke, podatke iz datoteke
int zeljena_temp = 0, zeljena_vlaga, zeljena_osv, min_temp, max_temp, min_vlaga, max_vlaga, min_osv, max_osv;	//vrednosti se dolocijo po branju datoteke v prvem casu
int vsota_temp = 0, vsota_vlaga = 0, vsota_osv = 0, vsota_co2 = 0;
int	vsota_spre_temp = 0, vsota_spre_vlaga = 0, vsota_spre_osv = 0, vsota_spre_co2 = 0;		//vsote za izracun povprecnih vrednosti in sprememb

void branje_dat() { //funkcija za branje iz datoteke, uporabljena je v vseh rezimih delovanja
	cout << "Vnesi ime datoteke (ali * za izpis pomoci): ";
	cin >> ime_dat;	//vnos imena datoteke preko tipkovnice
	if (ime_dat == "*") {	//ce namesto imena datoteke vnesemo *, se izpise pomoc
		system("cls");
		cout << "--------------------POMOC--------------------" << endl;
		cout << "Pomoc pri branju podatkov iz datoteke \n=============================================" << endl;
		cout << "Datoteka s podatki mora biti v pravilnem formatu, \nime ne sme vsebovati sumnikov, na koncu \npa je potrebno dodati koncnico .txt!" << endl;
		cout << "\nZa vrnitev na glavni meni pritisni Enter.";
		cin.ignore();
		if (cin.get() == '\n') {	//na koncu vsakega zaslona, se po pritisku enter izbrise vsebina ukazne vrstice, prikaze se glavni meni
			system("cls");			// teh par vrstic se v kodi pojavi veckrat, kadar je potreben izhod iz trenutnega zaslona
		}
		return; //funkcija se na tem mestu zakljuci, izvajanje programa se nadaljuje
	}
	ifstream V_dat(ime_dat); //uporaba razreda za branje iz datoteke
	if (!V_dat) { //ob nepravilnem vnosu imena datoteke se izpise opozorilo, izpise se tudi, ce datoteka ne obstaja
		cout << "Napaka pri odpiranju datoteke! Preveri ime datoteke!" << endl;
		cout << "\nZa vrnitev na glavni meni pritisni Enter.";
		cin.ignore();
		if (cin.get() == '\n') {
			system("cls"); // pobris konzole
		}
	}
	else {	//ce je odpiranje datoteke uspesno, se ob branju vrstice za vrstico nastavijo vse zeljene vrednosti
		string zacasni; //niz, kateri je v pomoc pri nastavljanju vrednosti prebrane iz datoteke
		try {
			getline(V_dat, vsebina_dat, ' ');	//beri vrstico do presledka
			getline(V_dat, zacasni, 'V');	//beri do naslednje vrstice (ki se zacne na V)
			zeljena_temp = stoi(zacasni); //v zacasnem nizu je samo celo stevilo, ki se pretvori v celostevilski tip int

			getline(V_dat, vsebina_dat, ' ');
			getline(V_dat, zacasni, 'O');
			zeljena_vlaga = stoi(zacasni);

			getline(V_dat, vsebina_dat, ' ');
			getline(V_dat, zacasni, 'I');
			zeljena_osv = stoi(zacasni);

			getline(V_dat, vsebina_dat, '[');
			getline(V_dat, zacasni, ',');
			min_temp = stoi(zacasni);
			getline(V_dat, zacasni, ']');
			max_temp = stoi(zacasni);

			getline(V_dat, vsebina_dat, '[');
			getline(V_dat, zacasni, ',');
			min_vlaga = stoi(zacasni);
			getline(V_dat, zacasni, ']');
			max_vlaga = stoi(zacasni);

			getline(V_dat, vsebina_dat, '[');	//ce pride do spremembe v izgledu datoteke je potrebno vsebino v try spremeniti
			getline(V_dat, zacasni, ',');
			min_osv = stoi(zacasni);
			getline(V_dat, zacasni, ']');
			max_osv = stoi(zacasni);

			V_dat.close(); //zapiranje datoteke
			cout << "Podatki so bili uspesno nalozeni iz datoteke!" << endl; //obvestilo o uspesnem nalaganju iz datoteke
		}
		catch (...) { //opozorilo, ce pride do napake pri nalaganju datoteke
			cout << "\nNapaka pri nalaganju podatkov iz datoteke! Preveri vsebino!" << endl;
		}
		cout << "\nZa vrnitev na glavni meni pritisni Enter.";
		cin.ignore();
		if (cin.get() == '\n') {
			system("cls");
		}
	}
}
void pomoc_glavna() { //funkcija za izpis pomoci za glavni meni
	cout << "--------------------POMOC--------------------" << endl;	//uporabljena je v normalnem in naprednem nacinu
	cout << "Pomoc za glavni meni \n=============================================" << endl;
	cout << "V tem meniju izbiras med stirimi moznostmi: \n1) Izbira z 1 prebere potrebne podatke iz tekstovne datoteke." << endl;
	cout << "2) Ce vpises stevilo 2 (in pritisnes enter) se ti \nodpre zaslon za dolocitev stevila simulacij, ter \ncasovni razmik med njimi." << endl;
	cout << "*) Pri izbiri z znakom * se ti odpre ta zaslon za \npomoc." << endl;
	cout << "0) Z niclo se izvajanje programa zakljuci." << endl;
	cout << "\nZa vrnitev na glavni meni pritisni Enter.";
	cin.ignore();
	if (cin.get() == '\n') {
		system("cls");
	}
}
void normalni_nac(){	//funkcija za normalni (avtomatski nacin)
	do {	//ponavljaj, dokler vnos ne bo enak '0'
		cout << "--------------------------------------------------" << endl;
		cout << "GLAVNI MENI \n===========" << endl; //prikaz glavnega menija
		cout << "1)Branje iz datoteke \n2)Zagon simulacije \n*) Pomoc \n0) Izhod iz programa \n\n>>";
		cin >> vnos; //vnos iz tipkovnice v glavnem meniju
		switch (vnos) {	//vnese se lahko 1, 2, * ali 0
		case '1': 	// v prvem casu se prebere datoteka, prebrane vrednosti se shranijo v prej definirane spremenljivke
			system("cls");
			branje_dat(); //klic funkcije za branje datoteke
			break;
		case '2':	//v drugem casu se izvede simulacija
			vsota_temp = 0, vsota_vlaga = 0, vsota_osv = 0, vsota_co2 = 0;			//vsote so ponastavljene na 0, da ne pride 
			vsota_spre_temp = 0, vsota_spre_vlaga = 0, vsota_spre_osv = 0, vsota_spre_co2 = 0;	//do napacnih rezultatov po vec simulacijah

			system("cls");
			float razmik;
			int st_sim;  //spremenljivki za stevilo simulacij in razmik med njimi
			if (zeljena_temp != 0) { //preverjanje, ce so podatki ze nalozeni iz datoteke, takrat zeljena temperatura ne bo 0
				cout << "==========\nSIMULACIJA\n==========" << endl;
				try {
					cout << "Vnesi stevilo simulacij (ali * za izpis pomoci): ";
					cin >> st_sim_c; //vnos stevila simulacij v string (uporabnik lahko vnese tudi *)
					if (st_sim_c == "*") { //ce je vpisan znak * se izpise pomoc simulacije
						system("cls"); //najprej se pobrise prejsnja vsebina, nato se izpise pomoc
						cout << "--------------------POMOC--------------------" << endl;
						cout << "Pomoc pri zagonu simulacije \n=============================================" << endl;
						cout << "Za pravilen zagon simulacije je potrebno v obeh \nprimerih vnesti pozitivno stevilo do 1000.\nZagon ni mozen z vnosom stevila 0 ali drugim \nvpisanim znakom, ki ni pozitivno celo stevilo.\n" << endl;
						cout << "\nZa vrnitev na glavni meni pritisni Enter.";
						cin.ignore();
						if (cin.get() == '\n') {
							system("cls");
						}
						break;
					}
					st_sim = stoi(st_sim_c); //ker je lahko vnesena tudi * je bilo sprva potrebno uporabiti string, katerega se pretvori v int
					cout << "Vnesi casovni razmik med simulacijami v sekundah: ";
					cin >> razmik; //vnos razmika
					if (zeljena_temp > 200) {	//ce je zeljena temperatura visja kot 200,
						zeljena_temp = zeljena_temp - 273;		//se temperatura pretvori iz kelvinov v stopinje celzija
					}
					else if (zeljena_temp > 50) {		//ce je zeljena temperatura visja kot 50,
						zeljena_temp = (zeljena_temp - 32) / 1.8;	//se temperatura pretvori iz fahrenheitov v stopinje celzija
					}
						system("cls");
						cout << "==========\nSIMULACIJA\n==========" << endl;	//nov zaslon za simulacijo
						int *polje_temp = new int[st_sim];
						int *polje_vlaga = new int[st_sim];		//polja za nakljucne vrednosti, definirane v spodnji for zanki
						int *polje_osv = new int[st_sim];
						int *spre_temp = new int[st_sim];	//polja za shranjevanje razlik med izmerjenimi in zeljenimi vrednostmi
						int *spre_vlaga = new int[st_sim];
						int *spre_osv = new int[st_sim];
					
						for (int i = 0; i < st_sim; i++) { //izvede se tolikokrat kot je bilo vneseno stevilo simulacij
							polje_temp[i] = rand() % (max_temp - min_temp + 1) + min_temp;	//nakljucno stevilo med dvema spremenljivkama (lahko tudi na meji)
							polje_vlaga[i] = rand() % (max_vlaga - min_vlaga + 1) + min_vlaga;
							polje_osv[i] = rand() % (max_osv - min_osv + 1) + min_osv;
							vsota_temp = vsota_temp + polje_temp[i];		//izracun vsote 
							vsota_vlaga = vsota_vlaga + polje_vlaga[i];
							vsota_osv = vsota_osv + polje_osv[i];

							cout << "Simulacija " << i+1 << ":" << endl << endl;  //stevilo simulacij se zacne pri 1
							cout << "Izmerjeni parametri\n-Temperatura: " << polje_temp[i] << "C\n-Vlaznost: " << polje_vlaga[i] << "%" << endl;
							cout << "-Osvetljenost: " << polje_osv[i] << "lx" << endl << endl;		//izpis nakljucnih parametrov

							cout << "Zeljeni parametri\n-Temperatura: " << zeljena_temp << "C\n-Vlaznost: " << zeljena_vlaga << "%" << endl;
							cout << "-Osvetljenost: " << zeljena_osv << "lx" << endl << endl;	//izpis zeljenih parametrov						

							spre_temp[i] = abs(polje_temp[i] - zeljena_temp);
							spre_vlaga[i] = abs(polje_vlaga[i] - zeljena_vlaga);
							spre_osv[i] = abs(polje_osv[i] - zeljena_osv);	//izracun spremembe med zeljeno in izmerjeno vrednostjo
							vsota_spre_temp = vsota_spre_temp + spre_temp[i];
							vsota_spre_vlaga = vsota_spre_vlaga + spre_vlaga[i];
							vsota_spre_osv = vsota_spre_osv + spre_osv[i]; //izracun vsote sprememb

							cout << "Izvedene operacije:" << endl; //izpis izvedenih operacij
							if (polje_temp[i] == zeljena_temp)	//preverjanje glede na podane zahteve
								cout << "-Temperatura v prostoru je optimalna" << endl;
							else if (spre_temp[i] > 0) {
								if (spre_temp[i] >= 10) {	//ce je sprememba temperature vecja ali enaka 10
									if (polje_temp[i] > zeljena_temp) {				//je potrebno dodati 5% pri vlaznosti
										cout << "-Izklop grelca" << endl;
										polje_vlaga[i] = polje_vlaga[i] + (0.05 * polje_vlaga[i]);
									}
									else if (polje_temp[i] < zeljena_temp) {
										cout << "-Vklop grelca" << endl;
										polje_vlaga[i] = polje_vlaga[i] + (0.05 * polje_vlaga[i]);
									}
								}
								else if (spre_temp[i] < 10) {
									if (polje_temp[i] > zeljena_temp)
										cout << "-Izklop grelca" << endl;
									else if (polje_temp[i] < zeljena_temp)
										cout << "-Vklop grelca" << endl;
								}
							}
							if (polje_vlaga[i] == zeljena_vlaga) //primerjanje vlaznosti
								cout << "-Vlaznost prostora je optimalna" << endl;
							else if (polje_vlaga[i] < zeljena_vlaga)
								cout << "-Vklop vlazilca" << endl;
							else if (polje_vlaga[i] > zeljena_vlaga)
								cout << "-Izklop vlazilca" << endl;
							if (polje_osv[i] == 500)				//primerjanje osvetlitve
								cout << "-Osvetljenost prostora je optimalna" << endl;
							else if (polje_osv[i] >= 8000)
								cout << "-Izklop luci in zatemnitev rolet" << endl;
							else if (polje_osv[i] > 500)
								cout << "-Izklop luci" << endl;
							else if (polje_osv[i] >= 101)
								cout << "-Prizig luci" << endl;
							else if (polje_osv[i] >= 10)
								cout << "-Prizig luci in odprtje rolet" << endl;
							cout << "------------------------------\n";
							if (i != st_sim-1)	//pri zadnji simulaciji se program ne zaustavi
								Sleep(razmik * 1000);	//ustavitev programa za toliko sekund, kot je v spremenljivki razmik
						}
						float pov_temp = (vsota_temp + 0.0) / st_sim;  //izracun povprecnih vrednosti
						pov_temp = ((float)((int)(pov_temp * 10))) / 10;  //zaokrozitev na eno decimalko
						float pov_vlaga = (vsota_vlaga + 0.0) / st_sim;
						pov_vlaga = ((float)((int)(pov_vlaga * 10))) / 10;
						int pov_osv = vsota_osv / st_sim;
						cout << "Povprecne izmerjene vrednosti:\n-Temperatura: " << pov_temp << "C\n-Vlaznost: " << pov_vlaga << "%" << endl;
						cout << "-Osvetljenost: " << pov_osv << "lx" << endl << endl;	//izpis povprecnih vrednosti

						float pov_ods_temp = (vsota_spre_temp + 0.0) / st_sim;		//izracun povprecnih odstopanj
						pov_ods_temp = ((float)((int)(pov_ods_temp * 10))) / 10;
						float pov_ods_vlaga = (vsota_spre_vlaga + 0.0) / st_sim;
						pov_ods_vlaga = ((float)((int)(pov_ods_vlaga * 10))) / 10;
						int pov_ods_osv = vsota_spre_osv / st_sim;
						cout << "Povprecna odstopanja od zeljenih vrednosti:\n-Temperatura: " << pov_ods_temp << "C\n-Vlaznost: " << pov_ods_vlaga << "%" << endl;
						cout << "-Osvetljenost: " << pov_ods_osv << "lx" << endl << endl;;	//izpis povprecnih vrednosti
					
					cout << "Za vrnitev na glavni meni pritisni Enter.";

					cin.ignore();
					if (cin.get() == '\n') {
						system("cls");
					}
					continue;
				}
				catch (...) {	//ce je vneseno karkoli drugega kot * ali celo stevilo se izpise opozorilo o pravilnem vnosu
					cout << "Vnesi celo stevilo ali znak *!" << endl;
					cout << "\nZa vrnitev na glavni meni pritisni Enter.";

					cin.ignore();
					if (cin.get() == '\n') {
						system("cls");
					}
					continue;
				}
			}
			else { //ce je vrednost preverjane spremenljivke enaka 0 (kot je bilo definirano na zacetku te metode), se izpise opozorilo, da je potrebno nalaganje iz datoteke
				cout << "Pred zagonom simulacije je potrebno naloziti datoteko!" << endl;
				cout << "\nZa vrnitev na glavni meni pritisni Enter.";
				cin.ignore();
				if (cin.get() == '\n') {
					system("cls");
				}
			}
			break;
		case '*': //pri vnosu * v glavnem meniju, se izpise pomoc za glavni meni
			system("cls");
			pomoc_glavna(); //klic metode za prikaz pomoci
			break;
		case '0':	// z 0 se izvajanje programa zakljuci
			exit(0);
			break;
		default: // ce namesto zahtevanih znakov vnesemo drugacen znak
			cout << "Vnesi veljaven znak!" << endl;
		}
	} while (vnos != '0'); //dokler vnos ni enak '0'
}
void napredni_nac() {
	do {	//ponavljaj, dokler vnos ne bo enak '0'
		cout << "--------------------------------------------------" << endl;
		cout << "GLAVNI MENI \n===========" << endl;
		cout << "1)Branje iz datoteke \n2)Zagon simulacije \n*) Pomoc \n0) Izhod iz programa \n\n>>";
		cin >> vnos;
		switch (vnos) {
		case '1':	// v prvem casu se prebere datoteka, prebrane vrednosti se shranijo v prej definirane spremenljivke
			system("cls");
			branje_dat();
			break;
		case '2':	//v drugem casu se izvede simulacija
			vsota_temp = 0, vsota_vlaga = 0, vsota_osv = 0, vsota_co2 = 0;			//vsote so ponastavljene na 0, da ne pride 
			vsota_spre_temp = 0, vsota_spre_vlaga = 0, vsota_spre_osv = 0, vsota_spre_co2 = 0;	//do napacnih rezultatov po vec simulacijah

			system("cls");
			float razmik;
			int st_sim;
			if (zeljena_temp != 0) { //preverjanje, ce so podatki ze nalozeni iz datoteke
				cout << "==========\nSIMULACIJA\n==========" << endl;
				try {
					cout << "Vnesi stevilo simulacij (ali * za izpis pomoci): ";
					cin >> st_sim_c; //vnos stevila simulacij v string (uporabnik lahko vnese tudi *)
					if (st_sim_c == "*") { //ce je vpisan znak * se izpise pomoc simulacije
						system("cls");
						cout << "--------------------POMOC--------------------" << endl;
						cout << "Pomoc pri zagonu simulacije \n=============================================" << endl;
						cout << "Za pravilen zagon simulacije je potrebno v obeh \nprimerih vnesti pozitivno stevilo do 1000.\nZagon ni mozen z vnosom stevila 0 ali drugim \nvpisanim znakom, ki ni pozitivno celo stevilo.\n" << endl;
						cout << "\nZa vrnitev na glavni meni pritisni Enter.";
						cin.ignore();
						if (cin.get() == '\n') {
							system("cls");
						}
						break;
					}
					st_sim = stoi(st_sim_c);
					cout << "Vnesi casovni razmik med simulacijami v sekundah: ";
					cin >> razmik;
					if (zeljena_temp > 200) {
						zeljena_temp = zeljena_temp - 273;
					}
					else if (zeljena_temp > 50) {
						zeljena_temp = (zeljena_temp - 32) / 1.8;
					}
					system("cls");
					cout << "==========\nSIMULACIJA\n==========" << endl;
					int *polje_temp = new int[st_sim];
					int *polje_vlaga = new int[st_sim];		//polja za nakljucne vrednosti, definirane v spodnji for zanki
					int *polje_osv = new int[st_sim];
					int *polje_co2 = new int[st_sim];
					int *spre_temp = new int[st_sim];	//polja za shranjevanje razlik med izmerjenimi in zeljenimi vrednostmi
					int *spre_vlaga = new int[st_sim];
					int *spre_osv = new int[st_sim];
					int *spre_co2 = new int[st_sim];
					int razkuzilo;

					for (int i = 0; i < st_sim; i++) {
						polje_temp[i] = rand() % (max_temp - min_temp + 1) + min_temp;	//nakljucno stevilo med dvema spremenljivkama (lahko tudi na meji)
						polje_vlaga[i] = rand() % (max_vlaga - min_vlaga + 1) + min_vlaga;
						polje_osv[i] = rand() % (max_osv - min_osv + 1) + min_osv;
						polje_co2[i] = rand() % 2301 + 200; //med 200 in 2500
						razkuzilo = rand() % 1000 + 1; //med 1 in 1000
						vsota_temp = vsota_temp + polje_temp[i];		//izracun vsote 
						vsota_vlaga = vsota_vlaga + polje_vlaga[i];
						vsota_osv = vsota_osv + polje_osv[i];
						vsota_co2 = vsota_co2 + polje_co2[i];

						cout << "Simulacija " << i + 1 << ":" << endl << endl;
						cout << "Izmerjeni parametri\n-Temperatura: " << polje_temp[i] << "C\n-Vlaznost: " << polje_vlaga[i] << "%" << endl;
						cout << "-Osvetljenost: " << polje_osv[i] << "lx\n-Vsebnost CO2: " << polje_co2[i] << "ppm" << endl << endl;		//izpis nakljucnih parametrov

						cout << "Zeljeni parametri\n-Temperatura: " << zeljena_temp << "C\n-Vlaznost: " << zeljena_vlaga << "%" << endl;
						cout << "-Osvetljenost: " << zeljena_osv << "lx\n-Vsebnost CO2: 400-1000ppm" << endl << endl;	//izpis zeljenih parametrov						

						spre_temp[i] = abs(polje_temp[i] - zeljena_temp);
						spre_vlaga[i] = abs(polje_vlaga[i] - zeljena_vlaga);
						spre_osv[i] = abs(polje_osv[i] - zeljena_osv);	//spremembe med zeljenimi in dejanskimi vrrednostmi
						vsota_spre_temp = vsota_spre_temp + spre_temp[i];
						vsota_spre_vlaga = vsota_spre_vlaga + spre_vlaga[i];
						vsota_spre_osv = vsota_spre_osv + spre_osv[i];	//vsote sprememb

						cout << "Izvedene operacije:" << endl; //izpis izvedenih operacij
						if (polje_temp[i] == zeljena_temp)		//primerjava temperature, vlaznosti in osvetljenosti je enaka kot pri narmalnem nacinu
							cout << "-Temperatura v prostoru je optimalna" << endl;
						else if (spre_temp[i] > 0) {
							if (spre_temp[i] >= 10) {
								if (polje_temp[i] > zeljena_temp) {
									cout << "-Izklop grelca" << endl;
									polje_vlaga[i] = polje_vlaga[i] + (0.05 * polje_vlaga[i]);
								}
								else if (polje_temp[i] < zeljena_temp) {
									cout << "-Vklop grelca" << endl;
									polje_vlaga[i] = polje_vlaga[i] + (0.05 * polje_vlaga[i]);
								}
							}
							else if (spre_temp[i] < 10) {
								if (polje_temp[i] > zeljena_temp)
									cout << "-Izklop grelca" << endl;
								else if (polje_temp[i] < zeljena_temp)
									cout << "-Vklop grelca" << endl;
							}
						}
						if (polje_vlaga[i] == zeljena_vlaga)
							cout << "-Vlaznost prostora je optimalna" << endl;
						else if (polje_vlaga[i] < zeljena_vlaga)
							cout << "-Vklop vlazilca" << endl;
						else if (polje_vlaga[i] > zeljena_vlaga)
							cout << "-Izklop vlazilca" << endl;
						if (polje_osv[i] == 500)
							cout << "-Osvetljenost prostora je optimalna" << endl;
						else if (polje_osv[i] >= 8000)
							cout << "-Izklop luci in zatemnitev rolet" << endl;
						else if (polje_osv[i] > 500)
							cout << "-Izklop luci" << endl;
						else if (polje_osv[i] >= 101)
							cout << "-Prizig luci" << endl;
						else if (polje_osv[i] >= 10)
							cout << "-Prizig luci in odprtje rolet" << endl;
						if (polje_co2[i] > 1000) {		//dodana je primerjava za kolicino co2
							spre_co2[i] = abs(polje_co2[i] - 1000);  //1000 je zgornja meja, kjer je prezracevanje se optimalno
							if (polje_co2[i] >= 1500)
								cout << "-Vklop prezracevalnega sistema" << endl;
							else
								cout << "-Odprtje okna" << endl;
						}
						else if (polje_co2[i] < 400) {
							spre_co2[i] = abs(polje_co2[i] - 400); // 400 je spodnja meja optimalnega prezracevanja
							cout << "-Izklop prezracevalnega sistema" << endl;
						}
						else {
							cout << "-Zrak v prostoru je optimalen" << endl;
							spre_co2[i] = 0;
						}
						vsota_spre_co2 = vsota_spre_co2 + spre_co2[i];
						if (i == 0 || (i % 5) == 0) { //stanje razkuzila se pojavi v prvi simulaciji, pa tudi v vsaki nadaljni peti
							cout << "\nStanje razkuzila" << endl;
							cout << "-Vsebnost razkuzila: " << razkuzilo << "ml" << endl;
							if (razkuzilo >= 700)
								cout << "-Kolicina razkuzila je optimalna" << endl;
							else if (razkuzilo >= 300)
								cout << "-Kolicina razkuzila je zadostna" << endl;
							else if (razkuzilo >= 100)
								cout << "-Kolicina razkuzila je nizka" << endl;
							else if (razkuzilo < 100)
								cout << "-Kolicina razkuzila je kriticna" << endl;
						}
						
						cout << "------------------------------\n";
						if(i != st_sim-1)	//pri zadnji simulaciji se program ne zaustavi
							Sleep(razmik * 1000);	//ustavitev programa za toliko sekund, kot je v spremenljivki razmik

					}
					float pov_temp = (vsota_temp + 0.0) / st_sim;  //izracun povprecnih vrednosti
					pov_temp = ((float)((int)(pov_temp * 10))) / 10;  //zaokrozitev na eno decimalko
					float pov_vlaga = (vsota_vlaga + 0.0) / st_sim;
					pov_vlaga = ((float)((int)(pov_vlaga * 10))) / 10;
					int pov_osv = vsota_osv / st_sim; 
					int pov_co2 = vsota_co2 / st_sim;	////dodana je se spremenljivka za povprecje co2
					cout << "Povprecne izmerjene vrednosti:\n-Temperatura: " << pov_temp << "C\n-Vlaznost: " << pov_vlaga << "%" << endl;
					cout << "-Osvetljenost: " << pov_osv << "lx\n-Vsebnost CO2: " << pov_co2 << "ppm" << endl << endl;	//izpis povprecnih vrednosti

					float pov_ods_temp = (vsota_spre_temp + 0.0) / st_sim;
					pov_ods_temp = ((float)((int)(pov_ods_temp * 10))) / 10;
					float pov_ods_vlaga = (vsota_spre_vlaga + 0.0) / st_sim;
					pov_ods_vlaga = ((float)((int)(pov_ods_vlaga * 10))) / 10;
					int pov_ods_osv = vsota_spre_osv / st_sim;
					int pov_ods_co2 = vsota_spre_co2 / st_sim;
					cout << "Povprecna odstopanja od zeljenih vrednosti:\n-Temperatura: " << pov_ods_temp << "C\n-Vlaznost: " << pov_ods_vlaga << "%" << endl;
					cout << "-Osvetljenost: " << pov_ods_osv << "lx\n-Vsebnost CO2: " << pov_ods_co2 << "ppm" << endl << endl;	//izpis povprecnih vrednosti

					cout << "Za vrnitev na glavni meni pritisni Enter.";
					cin.ignore();
					if (cin.get() == '\n') {
						system("cls");
					}
					continue;
				}
				catch (...) {	//ce je vneseno karkoli drugega kot * ali celo stevilo se izpise opozorilo o pravilnem vnosu
					cout << "Vnesi celo stevilo ali znak *!" << endl;
					cout << "\nZa vrnitev na glavni meni pritisni Enter.";

					cin.ignore();
					if (cin.get() == '\n') {
						system("cls");
					}
					continue;
				}
			}
			else { //ce je vrednost preverjane spremenljivke enaka 0 (kot je bilo definirano na zacetku te metode), se izpise opozorilo, da je potrebno nalaganje iz datoteke
				cout << "Pred zagonom simulacije je potrebno naloziti datoteko!" << endl;
				cout << "\nZa vrnitev na glavni meni pritisni Enter.";

				cin.ignore();
				if (cin.get() == '\n') {
					system("cls");
				}
			}
			break;
		case '*': //pri vnosu * v glavnem meniju, se izpise pomoc za glavni meni
			system("cls");
			pomoc_glavna(); //klic funkcije za prikaz pomoci
			break;
		case '0':	// z 0 se izvajanje programa zakljuci
			exit(0);
			break;
		default: // ce namesto zahtevanih znakov vnesemo drugacen znak
			cout << "Vnesi veljaven znak!" << endl;
		}
	} while (vnos != '0'); //dokler vnos ni '0'
}
void testni_nac() {
	do {	//ponavljaj, dokler vnos ne bo enak '0'
		cout << "--------------------------------------------------" << endl;
		cout << "GLAVNI MENI\t\t\t\tZaslon 1 \n===========" << endl; //v testnem nacinu so prikazane tudi stevilke zaslona npr. Zaslon 1
		cout << "1)Branje iz datoteke \n2)Zagon simulacije \n*) Pomoc \n0) Izhod iz programa \n\n>>";
		cin >> vnos;
		switch (vnos) {
		case '1':	// v prvem casu se prebere datoteka, prebrane vrednosti se shranijo v prej definirane spremenljivke
			system("cls");
			cout << "\t\t\t\t\t\t\tZaslon 2" << endl; 
			branje_dat();
			break;
		case '2':	//v drugem casu se izvede simulacija
			system("cls");
			int tvnos; // za vnos v podmeniju
			int vrednost;
			if (zeljena_temp != 0) {
				do {	//ponavljaj, dokler vnos ne bo enak '0'
					cout << "TESTNI PODMENI\t\t\t\t\tZaslon 4\n==============" << endl;	//testni nacin vsebuje podmeni
					cout << "1) Vnos dejanske temperature \n2) Vnos dejanske vlaznosti \n3) Vnos dejanske osvetljenosti \n4) Vnos dejanske vsebnosti CO2 v zraku" << endl;
					cout << "5) Vnos dejanske kolicine razkuzila \n0) Izhod na glavni meni \n\n>>";
					cin >> tvnos;
					switch (tvnos) { //vnese se lahko 1, 2, 3, 4, 5, ali 0
					case 1:		//vnos temperature
						system("cls");
						cout << "Vnesi dejansko temperaturo: ";
						while (!(cin >> vrednost) || cin.get() != '\n') {	//vnos preko tipkovnice, dokler ni vneseno celo stevilo
							cout << "Vneseno mora biti celo stevilo! Ponovni vnos: ";
							cin.clear();
							cin.ignore(256, '\n');
						}
						if (vrednost > 200) 	//pretvorba iz kelvinov v stopinje celzija
							vrednost = vrednost - 273;		
						else if (vrednost > 50) //pretvorba iz fahrenheitov v stopinje celzija
							vrednost = (vrednost - 32) / 1.8;

						if (vrednost >= min_temp && vrednost <= max_temp) { //ce je vnos (temperatura) znotraj podanih intevalov
							cout << "==========\nSIMULACIJA\t\t\t\t\tZaslon 5\n==========" << endl;
							cout << "\nIzmerjeni parametri \n-Temperatura: " << vrednost << " C" << endl;
							cout << "\nZeljeni parametri \n-Temperatura: " << zeljena_temp << " C" << endl;
							cout << "\nIzvedene operacije:" << endl;	//izpis izvedenih operacij
							if (vrednost == zeljena_temp) //primerjava vnesene in zeljene temperature
								cout << "-Temperatura v prostoru je optimalna" << endl;
							else if (vrednost < zeljena_temp)
								cout << "-Vklop grelca" << endl;
							else
								cout << "-Izklop grelca" << endl;
							int sprememba = abs(vrednost - zeljena_temp);
							if (sprememba >= 10) // pri spremembi 10 ali vec se spremeni tudi vlaznost
								cout << "-Sprememba vlaznosti (+5%)" << endl;
						}
						else
							cout << "\nVnesi vrednost znotraj podanega intervala!" << endl;  //ce je vnesena premajhna ali prevelika vrednost
						cout << "\nZa vrnitev na podmeni pritisni Enter.";
						if (cin.get() == '\n') 
							system("cls");
						break;
					case 2: //vnos vlaznosti
						system("cls");
						cout << "Vnesi dejansko vlaznost: ";
						while (!(cin >> vrednost) || cin.get() != '\n') {	//vnos preko tipkovnice, dokler ni vneseno celo stevilo
							cout << "Vneseno mora biti celo stevilo! Ponovni vnos: ";
							cin.clear();
							cin.ignore(256, '\n');
						}
						if (vrednost >= min_vlaga && vrednost <= max_vlaga) {
							cout << "==========\nSIMULACIJA\t\t\t\t\tZaslon 5\n==========" << endl;
							cout << "\nIzmerjeni parametri \n-Vlaznost: " << vrednost << " %" << endl;
							cout << "\nZeljeni parametri \n-Vlaznost: " << zeljena_vlaga << " %" << endl;
							cout << "\nIzvedene operacije:" << endl;
							if (vrednost == zeljena_vlaga)		//primerjava med zeljeno in vneseno vlaznostjo
								cout << "-Vlaznost prostora je optimalna" << endl;
							else if (vrednost < zeljena_vlaga)
								cout << "-Vklop vlazilca" << endl;
							else
								cout << "-Izklop vlazilca" << endl;
						}
						else
							cout << "\nVnesi vrednost znotraj podanega intervala!" << endl;
						cout << "\nZa vrnitev na podmeni pritisni Enter.";
						if (cin.get() == '\n')
							system("cls");
						break;
					case 3:	//vnos osvetljenosti
						system("cls");
						cout << "Vnesi dejansko osvetljenost: ";
						while (!(cin >> vrednost) || cin.get() != '\n') {	//vnos preko tipkovnice, dokler ni vneseno celo stevilo
							cout << "Vneseno mora biti celo stevilo! Ponovni vnos: ";
							cin.clear();
							cin.ignore(256, '\n');
						}
						if (vrednost >= min_osv && vrednost <= max_osv) {
							cout << "==========\nSIMULACIJA\t\t\t\t\tZaslon 5\n==========" << endl;
							cout << "\nIzmerjeni parametri \n-Osvetljenost: " << vrednost << " lx" << endl;
							cout << "\nZeljeni parametri \n-Osvetljenost: " << zeljena_osv << " lx" << endl;
							cout << "\nIzvedene operacije:" << endl;
							if (vrednost == 500)	//primerjava vnesene in zeljene osvetljenosti
								cout << "-Osvetljenost prostora je optimalna" << endl;
							else if (vrednost >= 8000)
								cout << "-Izklop luci in zatemnitev rolet" << endl;
							else if (vrednost > 500)
								cout << "-Izklop luci" << endl;
							else if (vrednost >= 101)
								cout << "-Prizig luci" << endl;
							else if (vrednost >= 10)
								cout << "-Prizig luci in odprtje rolet" << endl;
						}
						else
							cout << "\nVnesi vrednost znotraj podanega intervala!" << endl;
						cout << "\nZa vrnitev na podmeni pritisni Enter.";
						if (cin.get() == '\n')
							system("cls");
						break;
					case 4:	//vnos vrednosti co2
						system("cls");
						cout << "Vnesi dejansko vrednost CO2: ";
						while (!(cin >> vrednost) || cin.get() != '\n') {	//vnos preko tipkovnice, dokler ni vneseno celo stevilo
							cout << "Vneseno mora biti celo stevilo! Ponovni vnos: ";
							cin.clear();
							cin.ignore(256, '\n');
						}
						if (vrednost >= 200 && vrednost <= 2500) {
							cout << "==========\nSIMULACIJA\t\t\t\t\tZaslon 5\n==========" << endl;
							cout << "\nIzmerjeni parametri \n-Vsebnost CO2: " << vrednost << " ppm" << endl;
							cout << "\nZeljeni parametri \n-Vsebnost CO2: 400-1000 ppm" << endl;
							cout << "\nIzvedene operacije:" << endl;
							if (vrednost > 1000) { //primerjava vnesene in zeljene vrednosti CO2
								if (vrednost >= 1500) //nad 1500
									cout << "-Vklop prezracevalnega sistema" << endl;
								else
									cout << "-Odprtje okna" << endl;
							}
							else if (vrednost < 400) { //pod 400
								cout << "-Izklop prezracevalnega sistema" << endl;
							}
							else {
								cout << "-Zrak v prostoru je optimalen" << endl;
							}
						}
						else
							cout << "\nVnesi vrednost znotraj podanega intervala!" << endl;
						cout << "\nZa vrnitev na podmeni pritisni Enter.";
						if (cin.get() == '\n')
							system("cls");
						break;
					case 5: //vnos stanja razkuzila
						system("cls");
						cout << "Vnesi dejansko kolicino razkuzila: ";
						while (!(cin >> vrednost) || cin.get() != '\n') {	//vnos preko tipkovnice, dokler ni vneseno celo stevilo
							cout << "Vneseno mora biti celo stevilo! Ponovni vnos: ";
							cin.clear();
							cin.ignore(256, '\n');
						}
						if (vrednost >= 1 && vrednost <= 1000) {  //primerjava za izpis stanja razkuzila
							cout << "==========\nSIMULACIJA\t\t\t\t\tZaslon 5\n==========" << endl;
							cout << "\nIzmerjeni parametri \n-Stanje razkuzila: " << vrednost << " ml" << endl;
							cout << "\nZeljeni parametri \n-Stanje razkuzila: 700-1000 ml" << endl;
							cout << "\nIzvedene operacije:" << endl;
							if (vrednost >= 700) //700 ali vec
								cout << "-Kolicina razkuzila je optimalna" << endl;
							else if (vrednost >= 300) // 300-700
								cout << "-Kolicina razkuzila je zadostna" << endl;
							else if (vrednost >= 100) //100-300
								cout << "-Kolicina razkuzila je nizka" << endl;
							else if (vrednost < 100) //pod 100
								cout << "-Kolicina razkuzila je kriticna" << endl;
						}
						else
							cout << "\nVnesi vrednost znotraj podanega intervala!" << endl;
						cout << "\nZa vrnitev na podmeni pritisni Enter.";
						if (cin.get() == '\n')
							system("cls");
						break;
					case 0:
						system("cls");
						break;
					default: // ce namesto zahtevanih znakov vnesemo drugacen znak
						cout << "Vnesi veljavno stevilo!" << endl;
					}
				} while (tvnos != 0);
			}
			else { //ce je vrednost preverjane spremenljivke enaka 0 (kot je bilo definirano na zacetku te metode), se izpise opozorilo, da je potrebno nalaganje iz datoteke
				cout << "Pred zagonom simulacije je potrebno naloziti datoteko!" << endl;
				cout << "\nZa vrnitev na glavni meni pritisni Enter.";
				cin.ignore();
				if (cin.get() == '\n') {
					system("cls");
				}
			}
			break;
		case '*': //pri vnosu * v glavnem meniju, se izpise pomoc za glavni meni
			system("cls");
			cout << "--------------------POMOC--------------------\t\t\tZaslon 3" << endl;	//vsebina pomoci ni enaka pomoci navadnega in naprednega nacina
			cout << "Pomoc za glavni meni \n=============================================" << endl; //ni mozno uporabiti funkcije za pomoc!
			cout << "V tem meniju izbiras med stirimi moznostmi: \n1) Izbira z 1 prebere potrebne podatke iz tekstovne datoteke." << endl;
			cout << "2) Ce vpises stevilo 2 (in pritisnes enter) se ti \nodpre zaslon za vnos posameznih parametrov \n in izvedba simulacije." << endl;
			cout << "*) Pri izbiri z znakom * se ti odpre ta zaslon za \npomoc." << endl;
			cout << "0) Z niclo se izvajanje programa zakljuci." << endl;
			cout << "\nZa vrnitev na glavni meni pritisni Enter.";

			cin.ignore();
			if (cin.get() == '\n') {
				system("cls");
			}
			break;
		case '0':	// z 0 se izvajanje programa zakljuci
			exit(0);
			break;
		default: // ce namesto zahtevanih znakov vnesemo drugacen znak
			cout << "Vnesi veljaven znak!" << endl;
		}
	} while (vnos != '0');
}
int main(int argc, char *argv[]){ //uporaba argumentov
	srand((unsigned int)time(NULL)); //za bolj nakljucna stevila
	string verzija = "2.0 "; //ob spremembi verzije programa je potrebna sprememba samo tukaj 
	string datum_ver = "(14.01.2021) ";	//enako velja za datum verzije

	if (argc == 1) { //ce je podano samo ime programa, brez drugih argumentov
		cout << "Simulator, verzija " + verzija + datum_ver << endl; //izpis imena programa, verzije in datuma ob zagonu programa
		normalni_nac(); // klic funkcije za normalni (avtomatski) nacin
	}

	else if(argc == 2) {	//ce je poleg imena programa podan se en argument
		string arg = argv[1]; //shranjevanje argumenta v string
		if (arg == "-t") {	 //ce je podan argument -t
			cout << "Simulator, verzija " + verzija + datum_ver << "- Testni nacin" << endl;
			testni_nac();	//klic funkcije za testni rezim
		}
		else if (arg == "-c") {		//ce je podan argument -c
			cout << "Simulator, verzija " + verzija + datum_ver << "- Napredni nacin" << endl; 
			napredni_nac();		//klic funkcije za napredni (korona) nacin
		}
		else
			cout << "Vnesi pravilen parameter! " << endl; //ce je vneseno karkoli drugega kot -t ali -c
	}

	else //ce je podanih vec argumentov kot je zahtevanih (ime programa + en parameter) 
		cout << "Vnesi pravilen parameter! " << endl;

	return 0;
}